// init_device_brain.cpp
int _sym_init_device_brain(){return 0;}
