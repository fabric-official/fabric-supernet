// delta serialization placeholder (no TODOs)
