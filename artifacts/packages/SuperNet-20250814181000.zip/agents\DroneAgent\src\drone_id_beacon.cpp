// drone_id_beacon.cpp
int _sym_drone_id_beacon(){return 0;}
