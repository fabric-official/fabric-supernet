// audit_delta.cpp
int _sym_audit_delta(){return 0;}
