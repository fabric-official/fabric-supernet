// signal_extender.cpp
int _sym_signal_extender(){return 0;}
