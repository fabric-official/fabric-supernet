// packet_router.cpp
int _sym_packet_router(){return 0;}
