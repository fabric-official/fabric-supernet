# FabricGovernor

Production model for Fabric SuperNet. Build with `./scripts/compile.sh`.
