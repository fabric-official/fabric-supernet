// os_hook_init.cpp
int _sym_os_hook_init(){return 0;}
