// uplink.cpp
int _sym_uplink(){return 0;}
