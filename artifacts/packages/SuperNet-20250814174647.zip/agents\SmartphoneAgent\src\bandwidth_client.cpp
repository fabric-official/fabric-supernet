// bandwidth_client.cpp
int _sym_bandwidth_client(){return 0;}
