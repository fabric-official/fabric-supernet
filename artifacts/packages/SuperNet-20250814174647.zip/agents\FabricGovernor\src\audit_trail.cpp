// audit_trail.cpp
int _sym_audit_trail(){return 0;}
