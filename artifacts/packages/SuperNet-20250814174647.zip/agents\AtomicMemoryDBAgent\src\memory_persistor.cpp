// memory_persistor.cpp
int _sym_memory_persistor(){return 0;}
