// exec_multiplex.cpp
int _sym_exec_multiplex(){return 0;}
