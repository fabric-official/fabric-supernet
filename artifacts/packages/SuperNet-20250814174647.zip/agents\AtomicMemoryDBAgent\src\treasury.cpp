namespace treasury{ void require_budget_or_throw(){} }
