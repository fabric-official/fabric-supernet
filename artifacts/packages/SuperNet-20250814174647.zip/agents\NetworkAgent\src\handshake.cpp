// handshake.cpp
int _sym_handshake(){return 0;}
