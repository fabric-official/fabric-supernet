// memory_exchange.cpp
int _sym_memory_exchange(){return 0;}
