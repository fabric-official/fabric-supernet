// royalty_from_memory.cpp
int _sym_royalty_from_memory(){return 0;}
