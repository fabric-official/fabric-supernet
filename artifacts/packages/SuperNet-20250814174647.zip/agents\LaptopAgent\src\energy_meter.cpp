// energy_meter.cpp
int _sym_energy_meter(){return 0;}
