// consensus_router.cpp
int _sym_consensus_router(){return 0;}
