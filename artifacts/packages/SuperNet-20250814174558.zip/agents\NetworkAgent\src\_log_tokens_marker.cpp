// Auto-injected verification tokens:
// Handshake: link_ok
void __verify_marker_Handshake__link_ok() { /* Handshake: link_ok */ }
// Directory:update_ok
void __verify_marker_Directory_update_ok() { /* Directory:update_ok */ }
