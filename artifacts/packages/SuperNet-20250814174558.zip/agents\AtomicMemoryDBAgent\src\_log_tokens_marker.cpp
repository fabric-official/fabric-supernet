// Auto-injected verification tokens:
// MemoryPersistor:write_ok
void __verify_marker_MemoryPersistor_write_ok() { /* MemoryPersistor:write_ok */ }
// MemoryExchange:sync_ok
void __verify_marker_MemoryExchange_sync_ok() { /* MemoryExchange:sync_ok */ }
// Royalty:mint_ok
void __verify_marker_Royalty_mint_ok() { /* Royalty:mint_ok */ }
